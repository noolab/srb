def gettype(event, context):
    true=True
    false=False
    data={
      "type": "pickup",
      "postal": false,
      "pickup": true,
      "dropoff": false,
      "linehaul": false
    }
    return data
